//
//  HelloWorldApp.swift
//  HelloWorld
//
//  Created by GCCISAdmin on 1/23/24.
//

import SwiftUI

@main
struct HelloWorldApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
