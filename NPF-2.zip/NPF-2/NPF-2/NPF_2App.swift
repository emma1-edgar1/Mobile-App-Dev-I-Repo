//
//  NPF_2App.swift
//  NPF-2
//
//  Created by gccisadmin on 2/28/24.
//

import SwiftUI

@main
struct NPF_2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
