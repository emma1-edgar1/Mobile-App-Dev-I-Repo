import CoreLocation
class Park : CustomStringConvertible {
    private var parkName : String = ""
    private var parkLocation : String = ""
    private var dateFormed : String = ""
    private var area : String = ""
    private var link : String = ""
    
    private var location : CLLocation?
    private var imageLink : String = ""
    private var parkDescription : String = ""
    

    
    //mutators
    func getParkName() -> String {parkName}
    func set(newParkName: String) {parkName = newParkName}

    func getParkLocation() -> String {parkLocation}
    func set(newParkLocation: String) {parkLocation = newParkLocation}

    func getDateFormed() -> String {dateFormed}
    func set(newDateFormed: String) {dateFormed = newDateFormed}

    func getArea() -> String {area}
    func set(newArea: String) {area = newArea}

    func getLink() -> String {link}
    func set(newLink: String) {link = newLink}
    
    //must unwrap the location to read it.
    //func getLocation() -> CLLocation {location!}
    func getLocation() -> CLLocation? {
        if let unwrappedLocation = location {
               return unwrappedLocation
           } else {
               return nil
           }
    }
    func set(newLocation: CLLocation) {location = newLocation}

    func getimageLink() -> String {imageLink}
    func set(newImageLink: String) {imageLink = newImageLink}

    func getParkDescription() -> String {parkDescription}
    func set(newParkDescription: String) {parkDescription = newParkDescription}
    

    //initializers
    init(parkName: String = "", parkLocation: String = "", dateFormed: String = "", area: String = "", link: String = "", location: CLLocation?, imageLink: String = "", parkDescription: String = "") {
         self.parkName = parkName
         self.parkLocation = parkLocation
         self.dateFormed = dateFormed
         self.area = area
         self.link = link
         self.location = location
         self.imageLink = imageLink
         self.parkDescription = parkDescription
     }
    
    convenience init () {
        self.init(parkName: "Unknown", parkLocation: "Unknown",
                  dateFormed: "Unknown", area: "Unknown", link: "Unknown", location: nil, imageLink: "Unknown", parkDescription: "Unknown")
    }

    
    //custom print
    var description: String {
        return """
            {
                ParkName: \(getParkName())
                parkLocation: \(getParkLocation())
                dateFormed: \(getDateFormed())
                area: \(getArea())
                link: \(getLink())
                location: \(getLocation())
                imageLink: \(getimageLink())
                parkDescription: \(getParkDescription())
            
            }
            """
    }//description
}//Park


//create a park instance and print it out
let p1 = Park()
print(p1)

let p2 : Park = Park(parkName: "Acadia National Park", parkLocation: "Maine", dateFormed: "1919-02-26", area: "47,389.67 acres (191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD" )
//print(p2)
p2.set(newLink: "http://en.wikipedia.org/wiki/Acadia_National_Park")
print(p2)

let p3 = Park(parkName: "ab", parkLocation: "na", dateFormed: "1919-02-26", area: "47,389.67 acres(191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD")
print("\(p3)")
