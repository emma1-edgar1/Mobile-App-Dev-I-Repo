//
//  ContentView.swift
//  Greeter
//
//  Created by gccisadmin on 2/20/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var count = 0

    var body: some View {
        
        ///@Binding var value: String = " "
        
        VStack {
            Button(action: {
                //count += 1
            }, label: {
                /*@START_MENU_TOKEN@*/Text("Button")/*@END_MENU_TOKEN@*/
            }).buttonStyle(.borderedProminent)
            
//            .frame(width: /*@START_MENU_TOKEN@*/100/*@END_MENU_TOKEN@*/)
            HStack{
                ZStack {
                    Rectangle()
                        .fill(.green)
                        .cornerRadius(20)
                        .padding(25)
                    .frame(width: 200, height: 200)
                    Image(systemName: "plus")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                }//ZStack
                    
                ZStack {
                    Rectangle()
                        .fill(.red)
                        .cornerRadius(20)
                        .padding(25)
                    .frame(width: 200, height: 200)
                    Image(systemName: "minus")
                        .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                        .foregroundColor(.white)
                }//ZStack
            }//HStack
                .padding()
            
            Text("Count: \(count)")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            
            //TextField("Name", text: $value)
        }//VStack
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    }//body
}//ContentView

#Preview {
    ContentView()
}
