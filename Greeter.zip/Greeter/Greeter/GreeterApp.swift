//
//  GreeterApp.swift
//  Greeter
//
//  Created by gccisadmin on 2/20/24.
//

import SwiftUI

@main
struct GreeterApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
