//
//  ContentView.swift
//  HaHa
//
//  Created by GCCISAdmin on 2/13/24.
// Option + CMD + Enter -> preview mode on the left

import SwiftUI
import AVFoundation
//
//structs cant use inheritance
struct ShakeEffect: GeometryEffect {
    var position: CGFloat //cg = choregraphics
    
    //code completed automatically, it knows
    var animatableData: CGFloat {
        get { position }
        set { position = newValue }
    } //var animatableData
    
    init(shakes: Int) {
        position = CGFloat(shakes)
    }
    
    func effectValue(size: CGSize) -> ProjectionTransform {
        return ProjectionTransform(CGAffineTransform(translationX: -30 * sin(position * 2 * .pi), y: 0))
    }
    
}

struct ContentView: View {
    
    //need this to be a state variable to maintain itself between things and actually update. Need state to redraw the screen
    @State private var count = 0
    
    
    var body: some View {
            
        Color.purple
            .overlay(
                VStack{
                    
                    ButtonRow(count: $count)
                    
                    Spacer()
                    
                    Text("Haha # \(count)")
                        .font(.system(size:50))
                        .fontWeight(.bold)
                        .foregroundStyle(.black)
                    
                    
                    Spacer()
                    Image("nelson")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                   
                    
                    
                    
                }//VStack
            
            )//overlay
            .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
        
        
    }//body
    
    
//    @State private var count = 0
//    @State private var value = 0.2
    
//    var body: some View {
        
//        Color.blue
//            .overlay(
//                Image("nelson")
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width:300)
//                    .overlay(
//                        Rectangle()
//                            .foregroundColor(.black)
//                            .opacity(0.4)
//                            .overlay(
//                                Text("Nelson")
//                                    .font(.largeTitle)
//                                    .fontWeight(.black)
//                                    .foregroundStyle(.white)
//                                    .frame(width: 200)
//                            )//overlay with text again
//                    )//over lay with rect
//            )
 
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//                    .frame(width: 300)
//                    .clipShape(/*@START_MENU_TOKEN@*/Circle()/*@END_MENU_TOKEN@*/)
//                    .overlay(
//                        Text("Watch out for Nelson!")
//                            .fontWeight(.heavy)
//                            .font(.system(.headline, design: .rounded))
//                            .foregroundStyle(.white)
//                            .padding()
//                            .background(.black)
//                            .cornerRadius(10)
//                            .opacity(0.8)
//                            .padding(),
//                        alignment: .top
//                        //a little translucent heart over Nelson
//                        Image(systemName: "heart.fill")
//                            .font(.system(size:100))
//                            .foregroundColor(.black)
//                            .opacity(0.5)
//                    )//overlay with text
                    //other modifiers for the nelson image
//                    .clipped()
//                    .scaledToFit()
//                    .edgesIgnoringSafeArea()
//            )overlay with image
        

        
//        VStack{
//            
//            HStack{
//                //automatically divides the row into even spacing
//                Image(systemName: "aqi.low", variableValue: value)
//                Image(systemName: "wifi", variableValue: value)
//                Image(systemName: "chart.bar.fill", variableValue: value)
//                Image(systemName: "waveform", variableValue: value)
//            } //HStack
//            Slider(value: $value)
//            
//        }//VStack
//        .font(.system(size: 60))
//        .foregroundStyle(/*@START_MENU_TOKEN@*/.blue/*@END_MENU_TOKEN@*/)
//        .padding()
//        
        
//        VStack{
//            Image(systemName: "cloud.heavyrain")
//                .font(.system(size: 100))
//                .foregroundStyle(.blue)
//                .shadow(color: .gray, radius: 10, x:0, y: 10)
//                //ad a bounce effect to the image, will play each time
//                //the counter will change
//                .symbolEffect(.bounce, value: count)
//            
//            Button("Hello World"){
//                count += 1
//            }
//            .buttonStyle(.bordered)
//            
//            
//        }//Vstack
//        .padding()
//    }//body
}//Struct

        
#Preview {
    ContentView()
}

struct ButtonRow: View {
    
    @Binding var count: Int
    
    @State private var shakeIt  = false
    @State private var ShakeItAgain = false
    @StateObject private var myPlayer = MyPlayer()
    //could use @ObservedObjest wrapper but it only updates one view at a time. it would have its own copy this buttonRow.  you can't have two things reacting to the same object with @ObservedObject
    
    var body: some View {
        HStack{
            //PLAY BUTTON
            Button(action: {
                //only play the sound file if you can find it
                if myPlayer.player != nil {
                    count += 1
                    shakeIt.toggle()
                    //optional chaining
                    myPlayer.player?.play()
                    //vibrate during sound, needs an import statement
                    AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                    
                }
            }, label: {
                Image("bart_button")
                //if shake effect is set to true, shake it twice
                //modifiers cahnge the view 
                    .modifier(ShakeEffect(shakes: shakeIt ? 2 : 0))
                //this modifier will do a linear transiation when shakeIt changes
                    .animation(.linear, value: shakeIt)
            })
            //PlainButtonStyle is better for old devices
            .buttonStyle(PlainButtonStyle())
            
            
            Spacer()
            
            
            
            //PAUSE BUTTON
            Button(action: {
                //only play the sound file if you can find it
                if myPlayer.player != nil {
                    count -= 1
                    ShakeItAgain.toggle()
                    //optional chaining
                    myPlayer.player?.pause()
                    //vibrate during sound, needs an import statement
                    AudioServicesPlayAlertSound(SystemSoundID(kSystemSoundID_Vibrate))
                    
                }
            }, label: {
                Text("Pause")
                    .foregroundStyle(.white)
                //Image("bart_button")
                //if shake effect is set to true, shake it twice
                //modifiers cahnge the view
                    .modifier(ShakeEffect(shakes: ShakeItAgain ? 2 : 0))
                //this modifier will do a linear transiation when shakeIt changes
                    .animation(.bouncy, value: ShakeItAgain)
            })
        }//HStack
        .padding(.top, 50)
        .padding(.horizontal, 30)
    }
}
