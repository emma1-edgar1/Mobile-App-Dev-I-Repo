//
//  MapView.swift
//  FavoritePlaces
//
//  Created by GCCISAdmin on 3/21/24.
//

import SwiftUI
import Foundation
import MapKit

struct MapView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    MapView()
}
