//
//  FavoritePlacesApp.swift
//  FavoritePlaces
//
//  Created by GCCISAdmin on 3/21/24.
//

import SwiftUI

@main
struct FavoritePlacesApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
