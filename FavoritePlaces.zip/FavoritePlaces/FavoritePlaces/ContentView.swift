//
//  ContentView.swift
//  FavoritePlaces
//
//  Created by GCCISAdmin on 3/21/24.
//

import SwiftUI
import CoreLocation

struct ContentView: View {
    
    @State private var landmarks: [Landmark] = []
    
    init() {
        if let path = Bundle.main.path(forResource: "landmarks", ofType: "plist") {
            
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: path))
                //cast to a dict with String for a key, and Any for the type
                let tempDict = try PropertyListSerialization.propertyList(from: data, format: nil) as! [String:Any]
                
                print(tempDict)
                
                //force unwrap the optional from the dictionary
                let tempArray = tempDict["landmarks"]! as! Array<[String:Any]>
                
                var tempLandmarks: [Landmark] = []
                
                for dict in tempArray {
                    //get name and cast to string, with force unwrapping and force casting
                    let name = dict["name"] as! String
                    //or you can unwrap using the nil coalescing operator, this way is safer if the user has access to the data and might be editing it.
                    let state = dict["state"] as? String ?? "unknown"
                   
                    let latitude = dict["latitude"]! as! Double
                    let longitude = dict["longitude"]! as! Double
                    
                    //coreLocation must be imported!
                    let location = CLLocation(latitude: latitude, longitude: longitude)
                    
                    let lm = Landmark(name: name, state: state, location: location)
                    
                    tempLandmarks.append(lm)
                    
                }//for
                
                print("There are \(tempLandmarks.count) landmarks")
                print (tempLandmarks)
                
                //why underscore again...property wrapper doesnt take effect until init is DONE loading. need to use a 'fake' value until its done.
                _landmarks = State(initialValue: tempLandmarks)
                
            } catch {
                print(error)
            }
        }//if-let
    }//init
    
    
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
