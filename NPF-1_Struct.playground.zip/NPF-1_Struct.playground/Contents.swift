import CoreLocation
struct Park : CustomStringConvertible {
    private var parkName : String = ""
    private var parkLocation : String = ""
    private var dateFormed : String = ""
    private var area : String = ""
    private var link : String = ""
    
    private var location : CLLocation?
    private var imageLink : String = ""
    private var parkDescription : String = ""
    

    
    //mutators
    mutating func getParkName() -> String {parkName}
    mutating func set(newParkName: String) {
//        print("CURRENT PARK NAME is \(parkName)")
//        print("NEW PARK NAME to \(newParkName)")

        var newParkName = newParkName.trimmingCharacters(in: .whitespaces)
//        print("count: \(newParkName.count)")
        if newParkName.count > 3 && newParkName.count < 75 {
            parkName = newParkName
//            print("The name is bigger than 3 and less than 75 char.")
        } else {
            print("Bad value of '\(newParkName)' in set(ParkName): setting park name to TBD")
            parkName = "TBD"
        }
       
    }

    mutating func getParkLocation() -> String {parkLocation}
    mutating func set(newParkLocation: String) {
//        print("CURRENT PARK NAME is \(parkName)")
//        print("NEW PARK NAME to \(newParkName)")

        var newParkLocation = newParkLocation.trimmingCharacters(in: .whitespaces)
//        print("count: \(newParkName.count)")
        if newParkLocation.count > 3 && newParkLocation.count < 75 {
            parkLocation = newParkLocation
//            print("The name is bigger than 3 and less than 75 char.")
        } else {
            print("Bad value of '\(newParkLocation)' in setParkLocation(): setting park location to TBD")
            parkLocation = "TBD"
        }
    }

    mutating func getDateFormed() -> String {dateFormed}
    mutating func set(newDateFormed: String) {dateFormed = newDateFormed}

    mutating func getArea() -> String {area}
    mutating func set(newArea: String) {area = newArea}

    mutating func getLink() -> String {link}
    mutating func set(newLink: String) {link = newLink}
    
    //must unwrap the location to read it.
    //func getLocation() -> CLLocation {location!}
    mutating func getLocation() -> CLLocation? {
        if let unwrappedLocation = location {
               return unwrappedLocation
           } else {
               return nil
           }
    }
    mutating func set(newLocation: CLLocation) {location = newLocation}

    mutating func getimageLink() -> String {imageLink}
    mutating func set(newImageLink: String) {imageLink = newImageLink}

    mutating func getParkDescription() -> String {parkDescription}
    mutating func set(newParkDescription: String) {parkDescription = newParkDescription}
    

    //initializers
    init(parkName: String = "", parkLocation: String = "", dateFormed: String = "", area: String = "", link: String = "", location: CLLocation?, imageLink: String = "", parkDescription: String = "") {
         self.parkName = parkName
         self.parkLocation = parkLocation
         self.dateFormed = dateFormed
         self.area = area
         self.link = link
         self.location = location
         self.imageLink = imageLink
         self.parkDescription = parkDescription
     }
    

    
    //custom print
    var description: String {
        return """
            {
                ParkName: \(getParkName())
                parkLocation: \(getParkLocation())
                dateFormed: \(getDateFormed())
                area: \(getArea())
                link: \(getLink())
                location: \(getLocation())
                imageLink: \(getimageLink())
                parkDescription: \(getParkDescription())
            
            }
            """
    }//description
}//Park

extension Park {
    init () {
        self.init(parkName: "Unknown", parkLocation: "Unknown",
                  dateFormed: "Unknown", area: "Unknown", link: "Unknown", location: nil, imageLink: "Unknown", parkDescription: "Unknown")
    }
}


//create a park instance and print it out
let p1 = Park()
print(p1)



let p2 : Park = Park(parkName: "Acadia National Park", parkLocation: "Maine", dateFormed: "1919-02-26", area: "47,389.67 acres (191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD" )
print(p2)
p2.set(newLink: "http://en.wikipedia.org/wiki/Acadia_National_Park")
print(p2)





let p3 = Park(parkName: "ab", parkLocation: "na", dateFormed: "1919-02-26", area: "47,389.67 acres(191.8 square km)", link: "TBD", location: nil, imageLink: "TBD", parkDescription: "TBD")
p3.set(newParkName: "bl")
p3.set(newParkLocation: "ik")
print("\(p3)")

