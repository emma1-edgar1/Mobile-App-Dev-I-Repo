//
//  ContentView.swift
//  PlistTutorial
//
//  Created by GCCISAdmin on 2/20/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var personName = ""
    @State private var phoneNumbers = ["", "", ""]
    
    init(){
        //did we save this somewhere else, if we did...load that one. Otherwise use the one from the bundle that we created outselves
        if let documentPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            var plistPath = documentPathURL.appendingPathComponent("data.plist").path
//            
            //if the file isnt there you will have problems
            if !FileManager.default.fileExists(atPath: plistPath){
//                //we havent saved a modified version yet, so save default
                plistPath = Bundle.main.path(forResource: "data", ofType: "plist")!
            }//if
            
            
            print(plistPath)
            
            //like a try catchexcept all the things that need to be tried, need a 'try' keyword
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: plistPath))
                //takes data and turns it into a plist
                //reads in data as binary, then converts to plist then to dictionary
                let temp = try PropertyListSerialization.propertyList(from: data, options: .mutableContainersAndLeaves, format: nil) as! [String: Any]
                print(temp)
                
                //state doesnt exist yet, its a property wrapper
                //underscored versions of personName exist but not the actual one?
                //REmember - dicts return optionals
                //use nil coalescing to assign the value
//                state doesnt exist until init is done loading so we refer to them with the underscore
                self._personName = State(initialValue: temp["Name"] as? String ?? "TBD")
                self._phoneNumbers = State(initialValue: temp["Phones"] as? [String] ?? ["TBD", "TBD", "TBD"])
                
            } catch {
                print(error)
            }
            
            
        }//if let
    }// init
    
    var body: some View {
        VStack {
            FieldRow(label: "Name", hint: "Enter name...", value: $personName, keyboard: .alphabet)
            
            Text ("Phone Numbers")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding(.all, 10)
            
            FieldRow(label: "Home", hint: "Enter home phone....", value: $phoneNumbers[0], keyboard: .phonePad)
            FieldRow(label: "Work", hint: "Enter home phone....", value: $phoneNumbers[1], keyboard: .phonePad)
            FieldRow(label: "Cell", hint: "Enter home phone....", value: $phoneNumbers[2], keyboard: .phonePad)
            
            
            HStack {
                Button(action: {
                    saveData()
                    hideKeyboard()
                }, label: {
                    HStack{
                        Image(systemName: "square.and.arrow.down")
                        Text("Save Data")
                    }//HStack
                    .padding(10)
//                    .background(Capsule().stroke(lineWidth: 2.0))
            })
                .buttonStyle(.borderedProminent)
                .tint(.green)
                
                Button(action: {
                    deleteData()
                    hideKeyboard()
                }, label: {
                    HStack{
                        Image(systemName: "trash")
                        Text("Delete Data")
                    }//HStack
                    .padding(10)
//                    .background(Capsule().stroke(lineWidth: 2.0))
            })
                .buttonStyle(.bordered)
                .tint(.red)
                
            }//HStack
            
            Spacer()
            
            //need to create an extension to dismiss the keyboard
        }//VStack
        .padding()
    }//body
    
    
    func deleteData() {
        let fileMgr = FileManager.default
        
        //get url from document directory
        let dir = fileMgr.urls(for: .documentDirectory, in: .userDomainMask).first
        
        //print the contents of the directory
        print("\(try? fileMgr.contentsOfDirectory(atPath: dir!.path))")

        
        let fileUrl = dir!.appendingPathComponent("data.plist")
        
        
        do {
            try fileMgr.removeItem(atPath: fileUrl.path)
        } catch {
            print(error)
        }
    }
    
    func saveData() {
        if let documentPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            //get url to location
            let plistPath = documentPathURL.appendingPathComponent("data.plist")
            
            
            //create dictionary and write it to a file ...create plist path
            let plistDict:[String:Any] = [
                "Name":personName,
                "Phones": phoneNumbers
            ]
            
            do {
                let plistData = try PropertyListSerialization.data(fromPropertyList: plistDict, format: .xml, options: 0)
                
                try plistData.write(to:plistPath)
                
            } catch {
                print(error)
            }
            
        } //if - let
    }//saveData
}//ContentView


//extension to dismiss the keyboard
//whatever has focus is at the top of the responder chain
//outside
extension View {
    func hideKeyboard() {
        //..something creates a responder chain, chan choose to handle or bubble up the chain for someone else...if you already have a first responder open it will get rid of it? huhh? confusion.
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}


#Preview {
    ContentView()
}

struct FieldRow: View {
    
    var label: String
    var hint: String
    //anything that the user changes, make it stick and bind it
    @Binding var value: String
    var keyboard: UIKeyboardType
    
    
    var body: some View {
        HStack {
            Text(label)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding(.all, 10)
                .frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth: 125, alignment: .leading)
            
            //the $ is the binding value
            TextField(hint, text: $value)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(keyboard)
        }
    }
}
