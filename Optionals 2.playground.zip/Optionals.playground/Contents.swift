//let name:String? = "Emma"
//print(name)
//
////inferred as optional, type any
//let score = nil
//print(score)


class Vehicle {
    //verhicle can exists with or without a person. Opional property of type person
    var owner: Person?
    
    var wheels: Int = 4
    var name: String?
}//Vehicle

var car = Vehicle()
print(car.wheels)
print(car.name)

//force unwrap without checking for nil first
car.name = "McQueen"
print(car.name!)

//FORCE UNWRAP with !, check if its nil first!
let email: String? = "email@email.com"
if email != nil {
    print(email!)
}

//FORCE UNWRAP with if let ....
//scope of the 'if let...' username var is ONLY WITHIN THE BLOCK
let optusername: String? = "bob42"
if let username = optusername {
    print(username)
}//end of if

let firstName: String? = nil
let lastName: String? = nil
//let email: String? = nil


//OPTIONAL BINDING, nested force unwrapping, checks for nil andddd unwraps
//IF there is a value, LET the var be assigned
//if any one of the three do not have a value, it will not print
if let first_name = firstName,
   let last_name = lastName,
   let email = email {
    
    print("got it all woohoo")
}//end of if


if let score = Int("42a") {
    print(score)
}

//OPTIONAL BINDING BUT WITH A GUARD
//only difference is scope
func testGuard(username: String?) {
    guard let userName = username else {
        return
    }//end of else
    
    print ("Logged in as \(userName)")
}//testGuard


class DriversLicense {
    var points = 0
    
    func isValidFor(vehicle: Vehicle) -> Bool {
        //always return true
        true //"return" is optional here
    }
}//DriversLicense


class Person{
    //you could use weak or unowned here
    var license: DriversLicense?
}//Person


let andy = Person()
let points = 3
//nothing to assign to yet
andy.license?.points = points
//then create a drivers license
andy.license = DriversLicense()
car = Vehicle()
car.owner = andy


//so if andy does not have a license, we skip over this
if let canDriveVehicle = andy.license?.isValidFor(vehicle: car) {
    if canDriveVehicle{
        print("Andy has permission to drive")
    } else{
        print("GET ANDY OFF THE ROAD")
    }
} //if let canDriveVehicle

//check num points on license
if let points = car.owner?.license?.points {
    print("The car's owner has \(points) points on their license")
}

//so if andy has too many points on his license...


//what is this doing
if let _ = andy.license?.points += points {
    print ("Andy now has \(andy.license!.points) points")
}

//optional binding - preffered over forced unwrapping
if let license = andy.license {
    print ("Andy has \(license.points) points")
} else {
    print("Andy doesnt have a license")
}

//forced unrapping
if andy.license != nil {
    //didn't unwrap it sowe need to use the original value
    print ("Andy has \(andy.license!.points) points")
} else {
    print("Andy doesnt have a license")
}


//optional chaining - checks and continues if there is a value in the optional, then it is up to you to unwrap it
let pointsOnLicence = andy.license?.points
if let points = pointsOnLicence {
    print ("Andy has \(pointsOnLicence) points")
} else {
    print("Andy doesnt have a license")
}



///DICTIONARY

//a name tuple
var catelogue = ["Honda" : (minPrice: 10, maxPrice: 100)]
//remember all things from a dictionary are optionals because a key may or may not have a value,

var honda = catelogue["Honda"]
//returns an optional
print(honda)

//optional chaining with dictionary
if let price = catelogue["Honda"]?.minPrice {
    print ("The minimum price is \(price).")
}

//changes the value that is printed
if let _ = catelogue["Honda"]?.maxPrice = 30 {
    print(catelogue)
}


//remember when you get something from a dictionary, it is an optional, but the dict itself is also an optional
var otherCatelogue: Dictionary? = ["Lotus": (minPrice: 50, maxPrice: 200)]
//need to do optional chaining here, -> add ?
var lotus = otherCatelogue?["Lotus"]
if let price = otherCatelogue?["Lotus"]?.minPrice {
    print("The minimum price is \(price)")
}

//using the nil coalescing operator - used a lot of dictionaries so you dont have to unwrap later
//changed the value of minPrice, without the ?? 0, it would be nil
var minPriceOfCar = catelogue["Lotus"]?.minPrice ?? 0
print ("The minimum price is \(minPriceOfCar)")

//min price of Honad is not optioal so you MUST ??
minPriceOfCar = catelogue["Honda"]?.minPrice ?? 0
print ("The minimum price is \(minPriceOfCar)")
