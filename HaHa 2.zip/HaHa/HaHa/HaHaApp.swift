//
//  HaHaApp.swift
//  HaHa
//
//  Created by GCCISAdmin on 2/13/24.
//

import SwiftUI

@main
struct HaHaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
