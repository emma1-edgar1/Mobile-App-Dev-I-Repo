//
//  MyPlayer.swift
//  HaHa
//
//  Created by GCCISAdmin on 2/15/24.
//

import Foundation
import AVFoundation


class MyPlayer: ObservableObject {
    
    //@Published will notify listeners of changes
    @Published var player: AVAudioPlayer? = nil
    
    //define audio file name and file format in 'lets'
    let HA_HA_FILE = "haha"
    let HA_HA_FORMAT = "mp3"
    
    //when compiled everything in the nav pane are put in the main bundle (can read not write)
    init() {
        //look in bundle for the file
        //using if let because we may be returning an optional and if the file isn't working, it won't break the code
        if let soundFilePath = Bundle.main.path(forResource: HA_HA_FILE, ofType: HA_HA_FORMAT) {
            
            let fileUrl = URL(fileURLWithPath: soundFilePath)
            
            //like try-catch, EXCEPT you need to put 'try' on individual lines that you want to actually try to execute
            do {
                
                //any lines that could throw an exception, use 'try'
                //the 'try' says this line could throw an exception
                player = try AVAudioPlayer(contentsOf: fileUrl)
                
            } catch {
                player = nil
                print(error)
                //wll only show error in console
            }
            
        }// if-let
        else {
            player = nil
        }
        
        
        player?.prepareToPlay() //eliminates delay in playing the sound later
        
    }//init
    
}//MyPlayer
