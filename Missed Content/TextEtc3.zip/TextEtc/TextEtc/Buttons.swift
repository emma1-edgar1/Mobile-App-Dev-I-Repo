//
//  Buttons.swift
//  TextEtc
//
//  Created by GCCISAdmin on 2/6/24.
//

import SwiftUI

let gradient = LinearGradient(gradient: /*@START_MENU_TOKEN@*/Gradient(colors: [Color.red, Color.blue])/*@END_MENU_TOKEN@*/, startPoint: .topLeading, endPoint: .bottomTrailing)

struct Buttons: View {
    @State private var username = "" //nomrally would make private
    
    @State private var showText = false
    
    @State private var showingAlert = false
    
    var body: some View {
        
        VStack(alignment: .leading, spacing: 40) {
            
            UsernameView(username: $username, showText: $showText)
            
            Spacer()
            
            Button(action: {
                showingAlert = true
            }, label: {
                ZStack {
                    GreetButtonView()
                    
                    Text("Say Hello")
                        .font(.system(.caption, design: .rounded))
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .foregroundStyle(.white)
                        .padding(5)
                        .background(Color(red:255/255, green: 183.255, blue: 37/255))
                        .offset(x: 0, y:25)
                } //ZStack
            }) //Button
            .shadow(color: .blue, radius: 10.0)
            .alert("Greetings \(username)!", isPresented: $showingAlert) {
                //add buttons if you want with roles: .cancel, .destructive(red), .none
                //if you add any butons without a role of .cancel, it will automatically add a button with text of "cancel" that will only dismiss the alert
                
                Button("Save") {
                    
                }
                
                Button("Cancel", role: .cancel) {
                    //what to do if this button is clicked
                    
                }
                
                Button("No", role: .destructive) {
                    
                }
                
            } message: {
                Text("Hello \(username)")
            }
            
            Text("Your username: \(username)")
                .opacity(showText ? 1.0 : 0.0) //opaity is 1.0 if showText is true
            
        }//VStack
        .padding()
    } //body
} //strucut
    
#Preview {
    Buttons()
}

struct UsernameView: View {
    //use the state values as binding values - creating the parameters as two way bindings
    @Binding var username: String
    @Binding var showText: Bool
    
    var body: some View {
        HStack {
            Text("Enter Name: ")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(.title)
                .foregroundStyle(.gray)
            
            TextField("Enter username...", text: $username, onEditingChanged: {(changed) in print("Username onEditing changed - \(changed)")
            }) {
                showText.toggle()
            }
            .textFieldStyle(SuperCustomTextFieldStyle())
        }
    }
}

struct GreetButtonView: View {
    var body: some View {
        HStack {
            Image(systemName: "captions.bubble.fill")
            //.foregroundStyle(.white)
            Text("Greet!")
            //.foregroundStyle(.white)
        } //HStack
        .foregroundColor(.white) //modifier applies to everything in the Hstack
        .padding(10)
        .background(
            Capsule()
                .fill(gradient)
                .overlay(
                    Capsule()
                        .stroke(gradient, lineWidth: 2)
                ) //Capsule
        )
        .frame(minWidth: 0, maxWidth: .infinity, minHeight: 100, maxHeight: .infinity)
    }
}
