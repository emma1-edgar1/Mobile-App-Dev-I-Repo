//
//  ContentView.swift
//  TextEtc
//
//  Created by GCCISAdmin on 2/1/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var useBold = true
    
    var body: some View {
        
        //the .foregroundsStyle inside of a Text is iOS 17+
        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. In at nisl est. Maecenas commodo tincidunt magna in dictum. Sed eget viverra mauris. Vestibulum leo tortor, tristique posuere sapien et, tristique efficitur mi. Fusce placerat euismod risus. Suspendisse diam felis, convallis a malesuada et, imperdiet eget quam. Sed molestie pharetra dolor, nec accumsan sem ultrices ut. Morbi a lectus sed mi lobortis rutrum. Lorem ipsum dolor sit amet, consectetur adipiscing elit.") //view
            .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
            .font(.title)
            .foregroundColor(.gray)
            .multilineTextAlignment(.center)
            .lineLimit(3...6) //default is nil -- as many as will fit
            .truncationMode(.head)
            .lineSpacing(/*@START_MENU_TOKEN@*/10.0/*@END_MENU_TOKEN@*/)
            .rotation3DEffect(
                .degrees(60),
                axis: (x: 1.0, y: 0.0, z: 0.0)
            )
            .shadow(color: .blue, radius: /*@START_MENU_TOKEN@*/10/*@END_MENU_TOKEN@*/)
            //.rotationEffect(.degrees(45))
            //.rotationEffect(.degrees(20), anchor: UnitPoint(x: 20, y: 0))
            //.fontWeight(.bold) //modifier
//            .bold(useBold) //same for .italic
//            //the next 2 modifiers are using Dynamic Fonts
//            //.font(.title)
//            //.font(.system(.largeTitle, design: .rounded))
//            //or fixed size fonts
//            //.font(.system(size:20))
//            //custom font -- font name is found in Font Book
//            .font(.custom("Helvetica Neue", size: 25))
            .padding()
    }//body
}//struct

#Preview {
    ContentView()
}
