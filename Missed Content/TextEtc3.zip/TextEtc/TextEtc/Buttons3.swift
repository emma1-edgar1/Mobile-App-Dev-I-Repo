//
//  Buttons3.swift
//  TextEtc
//
//  Created by GCCISAdmin on 2/8/24.
//

import SwiftUI

struct Buttons3: View {
    var body: some View {
        VStack {
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                Text("The Solid")
                    .foregroundStyle(.white)
                    .padding()
            })
            .background(RoundedRectangle(cornerRadius: 10, style: .continuous)) //Button
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                Text("The Outline")
                    .padding()
            })
            .background(Capsule().stroke(lineWidth: 2))//Button
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                Text("The Transluscent Background")
                    .padding()
            })
            .background(RoundedRectangle(cornerRadius: 15, style: .continuous)).opacity(0.2)//Button
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                Text("The Gradient")
                    .padding()
            })
            .background(Capsule()
                .stroke(gradient, lineWidth: 10)
                .saturation(1.5))//Button
            
        } //VStack
    } //body
} //struct

#Preview {
    Buttons3()
}
