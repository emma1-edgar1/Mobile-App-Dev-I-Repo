//
//  Buttons2.swift
//  TextEtc
//
//  Created by GCCISAdmin on 2/8/24.
//

import SwiftUI

struct Buttons2: View {
    var body: some View {
        
        //using styling available since iOS5
        VStack {
            Button("Add") {
                //button action
            }
            .tint(.green)
            .buttonStyle(.borderedProminent)
            
            Button("Subtract") {
                //button action
            }
            .tint(.blue)
            
            Button("Multiply") {
                //button action
            }
            .tint(.red)
            
            Button("Divide") {
                //button action
            }
            .tint(.purple)
        } //VStack
        .buttonStyle(.bordered)
        .controlSize(.large)

    } //body
} //struct

#Preview {
    Buttons2()
}
