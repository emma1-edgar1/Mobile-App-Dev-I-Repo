//class Monster: CustomStringConvertible, CustomDebugStringConvertible {
//    
//    private var numHeads = 1
//    private var name = ""
//    private var weapons: [String] = []
//    private var undead: Bool
//    
//    var description: String {
//        "Name: \(name), Number of Heads: \(numHeads)"
//    }
//    var debugDescription: String {
//        "Name: \(name), Number of Heads: \(numHeads), weapons: \(weapons), undead: \(undead)"
//    }
//    
//    
//    func getNumHeads() -> Int { numHeads }
//    //func funcName(argumentLabel parameterLabel:Type [,...]) -> returnType
//    //to call this function: setNumHeads(5),
//    //without the _, it would be: setNumHeads(_numHeads:5)
//    func setNumHeads(_ _numHeads: Int) {
//        if _numHeads < 0 || _numHeads > 1000 {
//            numHeads = 500
//        } else {
//            numHeads = _numHeads
//        }
//    }
//    
//    func getName() -> String { name }
//    //preferred naming conventions
//    //parameter name is also the argument name
//    //so to call: set(name: "Dwarf")
//    func set(name: String) {
//        self.name = name
//    }
//    
//    func getWeapons() -> [String] { weapons }
//    func set(weapons:[String]) {
//        self.weapons = weapons
//    }
//    
//    
//    //designated initializer
//    init(numHeads: Int, name: String, weapons: [String], undead: Bool) {
//        self.undead = undead
//        setNumHeads(numHeads)
//        set(name:name)
//        set(weapons:weapons)
//        
//    }
//    
//    //convenience initializer
//    convenience init() {
//        self.init(numHeads: 1, name: "Orc", weapons: [], undead: false)
//    }
//    
//    func fearsomeRoar() {
//        print("Roar!!!1")
//    }
//    
//}//Monster

struct Monster: CustomStringConvertible, CustomDebugStringConvertible {
    
    var numHeads = 1
    var name = ""
    var weapons: [String] = []
    var undead: Bool
    
    var description: String {
        "Name: \(name), Number of Heads: \(numHeads)"
    }
    var debugDescription: String {
        "Name: \(name), Number of Heads: \(numHeads), weapons: \(weapons), undead: \(undead)"
    }
    
    
    func getNumHeads() -> Int { numHeads }
    //func funcName(argumentLabel parameterLabel:Type [,...]) -> returnType
    //to call this function: setNumHeads(5),
    //without the _, it would be: setNumHeads(_numHeads:5)
    mutating func setNumHeads(_ _numHeads: Int) {
        if _numHeads < 0 || _numHeads > 1000 {
            numHeads = 500
        } else {
            numHeads = _numHeads
        }
    }
    
    func getName() -> String { name }
    //preferred naming conventions
    //parameter name is also the argument name
    //so to call: set(name: "Dwarf")
    mutating func set(name: String) {
        self.name = name
    }
    
    func getWeapons() -> [String] { weapons }
    mutating func set(weapons:[String]) {
        self.weapons = weapons
    }
    
    func fearsomeRoar() {
        print("Roar!!!1")
    }
    
}//Monster Strict

extension Monster {
    
    init() {
        undead = false
        numHeads = 1
        name = "Orc"
        weapons = []
    }
    
}

var m1 = Monster()
print(m1)
print(m1.debugDescription)
m1.fearsomeRoar()
print("The monster's name is: \(m1.getName())")
m1.set(name: "Dog")
print("The monster's name is: \(m1.getName())")

let m2 = Monster(numHeads: 5000, name: "Dwarf", weapons: ["bad breath","hard head"], undead: true)
print(m2.debugDescription)
