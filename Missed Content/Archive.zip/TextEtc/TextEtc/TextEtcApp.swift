//
//  TextEtcApp.swift
//  TextEtc
//
//  Created by bfrench on 2/1/24.
//

import SwiftUI

@main
struct TextEtcApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
