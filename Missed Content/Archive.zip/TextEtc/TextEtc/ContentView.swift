//
//  ContentView.swift
//  TextEtc
//
//  Created by bfrench on 2/1/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var useBold = true
    
    var body: some View {
        
        //the .foregroundStyle inside of a Text is iOS 17+
        Text("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris auctor urna egestas, elementum risus ut, mollis dolor. Aenean dui diam, ornare et tempus ut, imperdiet at odio. Aenean eu leo elit. Vestibulum molestie vulputate nisl, vitae laoreet enim ultricies sed. Phasellus sed sem tristique ipsum accumsan venenatis eget a velit. In id ornare diam. Vivamus in rhoncus urna, in cursus nunc. Curabitur in libero sem. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras ligula augue, feugiat ut purus nec, scelerisque sollicitudin quam. Nam tempus, massa posuere efficitur mattis, arcu odio tempor lacus, sed eleifend mauris diam aliquam ligula. Donec condimentum sodales justo lobortis porta. Donec porta arcu vel scelerisque semper. Nulla dignissim urna eget sapien blandit imperdiet.") //view
            .fontWeight(.bold)
            .font(.title)
            .foregroundColor(.gray)
            .multilineTextAlignment(.center)
            .lineLimit(3...6) //default is nil - as many as will fit
            .truncationMode(.head)
            .lineSpacing(10.0)
            //.fontWeight(.bold) //modifier
            //.bold(useBold) //same for .italic()
            //the next 2 modifiers are using Dynamic Fonts
            //.font(.title)
            //.font(.system(.largeTitle, design: .rounded))
            //or fixed sized font
            //.font(.system(size: 20))
            //custom font
            //.font(.custom("Helvetica Neue", size: 25))
        
            .padding()
        
    }//body
}//struct

#Preview {
    ContentView()
}
