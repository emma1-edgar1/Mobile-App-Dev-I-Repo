
import SwiftUI

struct SuperCustomTextFieldStyle: TextFieldStyle {
    
    func _body(configuration: TextField<_Label>) -> some View {
        configuration
            .padding()
            .background(.blue)
            .foregroundStyle(.white)
            .cornerRadius(15.0)
    }
} //style struct

struct EntryField: View {
    
    @State var username = "" //nomrally would make private
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            Text("Enter Name: ")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(.title)
            .foregroundStyle(.gray)
            
            TextField("Enter username...", text: $username, onEditingChanged: {(changed) in print("Username onEditing changed - \(changed)")
            }) {
                print("Username onCommit")
            }
            .foregroundStyle(.white)
            .background(.blue)
            .cornerRadius(5.0)
            //the above 3 or
            //.textFieldStyle(RoundedBorderTextFieldStyle())
            
            .textFieldStyle(SuperCustomTextFieldStyle())
            .keyboardType(/*@START_MENU_TOKEN@*/.default/*@END_MENU_TOKEN@*/)
            .textContentType(.username)
            
            Text("Your username: \(username)")
            
        } //VStack
     
        .padding()
        
    }
}

#Preview {
    EntryField()
}
