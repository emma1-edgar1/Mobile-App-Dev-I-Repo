
import SwiftUI

struct EntryField2: View {
    
    @State private var name = ""
    @State private var location = ""
    @State private var date = Date()
    @State private var hasNextField = false
    @State private var hasPreviousField = true
    
    var body: some View {
        
        Form {
            TextField("Name: ", text: $name, prompt: Text("Enter name"))
                .submitLabel(.next) //changes return key label
                .onSubmit {
                    //do something
                    print("Name submitted")
                }
            
            TextField("Location: ", text: $location)
            
            DatePicker("Date", selection: $date)
        } //Form
        .toolbar {
            
            ToolbarItemGroup(placement: .keyboard) {
                Button(action: selectPreviousField, label: {
                    Label("Previous", systemImage: "chevron.up")
                }) //button
                .disabled(!hasPreviousField)
                
                Button(action: selectNextField, label: {
                     Label("next", systemImage: "chevron.down")
                })
                .disabled(!hasNextField)
            } //group
                             
        } //toolbar
        
    } //body

    private func selectPreviousField() {
        //change focus, use focus modifier and states
        //detect focus, dismiss keyboard etc
        
        }

    private func selectNextField() {
        
        }
} //struct

#Preview {
    EntryField2()
}
