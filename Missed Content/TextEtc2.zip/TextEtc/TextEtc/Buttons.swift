//
//  Buttons.swift
//  TextEtc
//
//  Created by GCCISAdmin on 2/6/24.
//

import SwiftUI

let gradient = LinearGradient(gradient: /*@START_MENU_TOKEN@*/Gradient(colors: [Color.red, Color.blue])/*@END_MENU_TOKEN@*/, startPoint: .topLeading, endPoint: .bottomTrailing)

struct Buttons: View {
    @State private var username = "" //nomrally would make private
    
    var body: some View {
        
        VStack(alignment: .leading) {
            
            Text("Enter Name: ")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(.title)
                .foregroundStyle(.gray)
            
            TextField("Enter username...", text: $username, onEditingChanged: {(changed) in print("Username onEditing changed - \(changed)")
            }) {
                print("Username onCommit")
            }
            .textFieldStyle(SuperCustomTextFieldStyle())
            
            Button(action: {
                print("ButtonAction")
            }, label: {
                HStack {
                    Image(systemName: "captions.bubble.fill")
                    Text("Greet!")
                } //HStack
            }) //Button
            
            Text("Your username: \(username)")
            
        }//VStack
        .padding()
    } //body
} //strucut
    
#Preview {
    Buttons()
}
