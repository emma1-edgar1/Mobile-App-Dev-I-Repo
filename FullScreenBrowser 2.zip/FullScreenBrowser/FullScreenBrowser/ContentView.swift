//
//  ContentView.swift
//  FullScreenBrowser
//
//  Created by GCCISAdmin on 1/16/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        //ios requires httpS! Need to change settings if you want just http
        WebView(url: "https://www.rit.edu") //view
            //.edgesIgnoringSafeArea(.all) //modifier
            .ignoresSafeArea()
    } //body
} //struct

#Preview {
    ContentView()
}
