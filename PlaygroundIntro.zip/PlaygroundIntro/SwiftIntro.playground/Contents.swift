let tutorialTeam = 56
let editorialTeam = 23
var totalTeam = tutorialTeam + editorialTeam

totalTeam += 1

let price: Double = 19.99
let onsale: Bool = false

let name = "gymnastics"

let str = """
this is a  string
many lines
    many lines
    many lines
"""

print(str)

//single line comment

/* multi
 line
 comment
 */

if onsale {
    print("\(name) on sale for \(price)")
    
} else {
    print("\(name) at regular for \(price)")
}


class TipCalculator {
    let total: Double
    let taxPct: Double
    let subtotal: Double
    
    init(total: Double, taxPct: Double) {
        self.total = total
        self.taxPct = taxPct
        subtotal = total / (taxPct + 1)
    }
    
    func calcTipWith (tipPct: Double) -> Double {
        subtotal * tipPct //don't need a return statement with a single line function
    }
    
//    func printPossibleTips() {
//        //no params, no types
////        print("15%: \(calcTipWith(tipPct: 0.15))")
//        let possibleTips = [0.15, 0.18, 0.20]
//        
//        for possibleTip in possibleTips {
//            print("\(possibleTip*100)%: \(calcTipWith(tipPct: possibleTip))")
//        }
//
//        for i in 0..<possibleTips.count {
//            let possibleTip = possibleTips[i]
//            print("\(possibleTip*100)%: \(calcTipWith(tipPct: possibleTip))")
//        }
//    }
    
    func returnPossibleTips() -> [Int:Double] { //or Dictionary<Int, Double>
        let possibleTips = [0.15, 0.18, 0.20]
        
        var retVal = [Int:Double]() //or Dictionary<Int, Double>()
        for possibleTip in possibleTips {
            let intPct = Int(possibleTip*100)
            retVal[intPct] = calcTipWith(tipPct: possibleTip)
        }
        
        return retVal
        
    }
}//TipCalculator


let tipCalc = TipCalculator(total: 33.25, taxPct: 0.06)
tipCalc.returnPossibleTips()
