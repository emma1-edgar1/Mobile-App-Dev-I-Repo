//let name:String? = "Emma"
//print(name)
//
////inferred as optional, type any
//let score = nil
//print(score)


class Vehicle {
    var wheels: Int = 4
    var name: String?
}//Vehicle

let car = Vehicle()
print(car.wheels)
print(car.name)

//force unwrap without checking for nil first
car.name = "McQueen"
print(car.name!)

//FORCE UNWRAP with !, check if its nil first!
let email: String? = "email@email.com"
if email != nil {
    print(email!)
}

//FORCE UNWRAP with if let ....
//scope of the 'if let...' username var is ONLY WITHIN THE BLOCK
let optusername: String? = "bob42"
if let username = optusername {
    print(username)
}//end of if

let firstName: String? = nil
let lastName: String? = nil
//let email: String? = nil


//OPTIONAL BINDING, nested force unwrapping, checks for nil andddd unwraps
//IF there is a value, LET the var be assigned
//if any one of the three do not have a value, it will not print
if let first_name = firstName,
   let last_name = lastName,
   let email = email {
    
    print("got it all woohoo")
}//end of if


if let score = Int("42a") {
    print(score)
}

//OPTIONAL BINDING BUT WITH A GUARD
//only difference is scope
func testGuard(username: String?) {
    guard let userName = username else {
        return
    }//end of else
    
    print ("Logged in as \(userName)")
}//testGuard


class DriversLicense {
    var points = 0
}//DriversLicense


class Person{
    //you could use weak or unowned here
    var license: DriversLicense?
}//Person


let andy = Person()

//optional binding
if let license = andy.license {
    print ("Andy has \(license.points) points")
} else {
    print("Andy doesnt have a license")
}

