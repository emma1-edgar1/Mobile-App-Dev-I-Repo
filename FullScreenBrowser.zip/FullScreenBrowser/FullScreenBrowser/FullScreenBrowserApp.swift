//
//  FullScreenBrowserApp.swift
//  FullScreenBrowser
//
//  Created by GCCISAdmin on 1/16/24.
//

import SwiftUI

@main
struct FullScreenBrowserApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
