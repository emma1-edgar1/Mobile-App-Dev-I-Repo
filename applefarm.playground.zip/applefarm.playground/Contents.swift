//class appleFarm {
//    var name: String = "farm1"
//    
//}
//
//let farmOne = appleFarm()
//print (farmOne.name)
//


class appleFarm {
    var name = "Stanton"
    var salesToday: Int?
    var applesInStock: Int = 10
}//appleFarm
//initialize object
let farmOne = appleFarm()
print(farmOne.name)
print("Apples In Stock:", farmOne.applesInStock)

//force unwrap IF NOT nil
//what happes if you unwrap a nil var?
if farmOne.salesToday != nil{
    print(farmOne.salesToday!, "sales today!")
} else {
    print("no sales yet today")
}

//make purchase func
//run in while loop...while desire == true, run the loop. if desire is false, end loop and close stand.
print ("Would you like to make a purchase?")
//var answer = readLine()
//print(answer)

//how do you get user input??
if let answer = readLine() {
    print("Ok, your answer is \(answer)")
} else {
    print("no answer")
}
