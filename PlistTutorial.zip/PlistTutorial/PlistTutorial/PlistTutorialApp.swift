//
//  PlistTutorialApp.swift
//  PlistTutorial
//
//  Created by GCCISAdmin on 2/20/24.
//

import SwiftUI

@main
struct PlistTutorialApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
