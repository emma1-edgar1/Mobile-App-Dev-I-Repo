//
//  ContentView.swift
//  PlistTutorial
//
//  Created by GCCISAdmin on 2/20/24.
//

import SwiftUI

struct ContentView: View {
    
    @State private var personName = ""
    @State private var phoneNumbers = ["", "", ""]
    
    init(){
        if let documentPathURL = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first {
            
            var plistPath = documentPathURL.appendingPathComponent("data.plist").path
//            
            //if the file isnt there you will have problems
            if !FileManager.default.fileExists(atPath: plistPath){
//                //we havent saved a modified version yet, so save default
                plistPath = Bundle.main.path(forResource: "data", ofType: "plist")!
            }//if
            
            
            print(plistPath)
            
            //like a try catchexcept all the things that need to be tried, need a 'try' keyword
            do {
                let data = try Data(contentsOf: URL(fileURLWithPath: plistPath))
                //takes data and turns it into a plist
                //reads in data as inary, then converts to plist then to dictionary
                let temp = try PropertyListSerialization.propertyList(from: data, options: .mutableContainersAndLeaves, format: nil) as! [String: Any]
                print(temp)
                
                //state doesnt exist yet, its a property wrapper
                //underscored versions of personName exist but not the actual one?
                //REmember - dicts return optionals
                //use nil coalescing to assign the value
                self._personName = State(initialValue: temp["Name"] as? String ?? "TBD")
                self._phoneNumbers = State(initialValue: temp["Phones"] as? [String] ?? ["TBD", "TBD", "TBD"])
                
            } catch {
                print(error)
            }
            
            
        }//if let
    }// init
    
    var body: some View {
        VStack {
            FieldRow(label: "Name", hint: "Enter name...", value: $personName, keyboard: .alphabet)
            
            Text ("Phone Numbers")
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding(.all, 10)
            
            FieldRow(label: "Home", hint: "Enter home phone....", value: $phoneNumbers[0], keyboard: .phonePad)
            FieldRow(label: "Work", hint: "Enter home phone....", value: $phoneNumbers[1], keyboard: .phonePad)
            FieldRow(label: "Cell", hint: "Enter home phone....", value: $phoneNumbers[2], keyboard: .phonePad)
            
            
            Button(action: /*@START_MENU_TOKEN@*/{}/*@END_MENU_TOKEN@*/, label: {
                HStack{
                    Image(systemName: "square.and.arrow.down")
                    Text("Save Data")
                }//HStack
                .padding(10)
                .background(Capsule().stroke(lineWidth: 2.0))
            })
            
            Spacer()
            
            //need to create an extension to dismiss the keyboard
        }//VStack
        .padding()
    }//body
}//ContentView


//extension to dismiss the keyboard
extension View {
    func hideKeyboard() {
        //..something creates a responder chain, chan choose to handle or bubble up the chain for someone else...if you already have a first responder open it will get rid of it? huhh? confusion.
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}


#Preview {
    ContentView()
}

struct FieldRow: View {
    
    var label: String
    var hint: String
    //anything that the user changes, make it stick and bind it
    @Binding var value: String
    var keyboard: UIKeyboardType
    
    
    var body: some View {
        HStack {
            Text(label)
                .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                .padding(.all, 10)
                .frame(minWidth: /*@START_MENU_TOKEN@*/0/*@END_MENU_TOKEN@*/, maxWidth: 125, alignment: .leading)
            
            //the $ is the binding value
            TextField(hint, text: $value)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .keyboardType(keyboard)
        }
    }
}
