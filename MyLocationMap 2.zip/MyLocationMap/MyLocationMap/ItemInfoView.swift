//
//  ItemInfoView.swift
//  MyLocationMap
//
//  Created by GCCISAdmin on 3/19/24.
//

import SwiftUI
import MapKit

struct ItemInfoView: View {
    
    var selectedResult: MKMapItem
    //display the lookaround view but wont knwo the route until it comes back.
    var route: MKRoute?

    @State private var lookaroundScene: MKLookAroundScene?
    
    //a computed property that takes the route (if available) and gets the expected travel time and format it to hours and minutes.
    private var travelTime: String? {
        guard let route else { return nil }
        let formatter = DateComponentsFormatter()
        formatter.unitsStyle = .abbreviated
        formatter.allowedUnits = [.hour, .minute]
        return formatter.string(from: route.expectedTravelTime)
    }
    
    
    private func getLookAroundScene(){
        lookaroundScene = nil
        //do it in the background with an async task
        Task{
            let request = MKLookAroundSceneRequest(mapItem: selectedResult)
            lookaroundScene = try? await request.scene
        }
    }
    
    var body: some View {

        LookAroundPreview(initialScene: lookaroundScene)
            .overlay(alignment: .bottomTrailing){
                HStack {
                    Text("\(selectedResult.name ?? "")")
                    if let travelTime {
                        Text(travelTime)
                    }//if-let
                }//HStack
                .font(.caption)
                .foregroundStyle(.white)
                .padding(10)
                
            }//overlay
            .onAppear{
                getLookAroundScene()
                
            }
            .onChange(of: selectedResult) {
                getLookAroundScene()
            }
        
        
        
    }//body
}//View
