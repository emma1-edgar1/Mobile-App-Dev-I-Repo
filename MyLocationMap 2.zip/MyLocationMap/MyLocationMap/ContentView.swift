//
//  ContentView.swift
//  MyLocationMap
//
//  Created by bfrench on 3/7/24.
//

import SwiftUI
import MapKit

struct ContentView: View {
    
    @State private var searchResults: [MKMapItem] = []
    @State private var selectedResult: MKMapItem?
    @State private var selectedTag: Int?
    @State private var position: MapCameraPosition = .automatic
    @State private var visibleRegion: MKCoordinateRegion?
    @State private var route: MKRoute?
    
    var body: some View {
        
        Map(position: $position, selection: $selectedResult) {
            
            //Marker("RIT", coordinate: .rit)
            
            Annotation("RIT", coordinate: .rit) {
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(.background)
                    
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(.secondary, lineWidth: 5)
                    
                    Image(systemName: "building.columns")
                        .padding(5)
                    
                }//ZStack
                
            }//Annotation
            .annotationTitles(.hidden)
            
            ForEach( searchResults, id: \.self) { result in
                Marker(item: result)
            }
            .annotationTitles(.hidden)
            //if you have a lot, you can just reuse the tags you have instead of making lots.
//            Marker("U of R", monogram: Text("UoR"), coordinate: CLLocationCoordinate2D(latitude: 43.1306, longitude: -77.6260))
//                .tint(.purple)
//            Marker("U of R", systemImage: "car.fill", coordinate: CLLocationCoordinate2D(latitude: 43.1306, longitude: -77.6260))
            
            
        }//Map
        .mapStyle(.hybrid(elevation: .realistic))
        .safeAreaInset(edge: .bottom) {
            
            HStack {
                Spacer()
                VStack(spacing: 0) {
                    
                    if let selectedResult {
                        ItemInfoView(selectedResult: selectedResult, route: route)
                            .frame(height: 128)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
                            .padding([.top, .horizontal])
                    }
                    
                    RochesterButtons(position: $position, searchResults: $searchResults, visibleRegion: visibleRegion)
                        .padding([.top, .horizontal])
                }//VStack
                Spacer()
            }//HStack
            
        }//safeareainset
        .onChange(of: searchResults) {
            position = .automatic
        }
        .onChange(of: selectedResult) {
            getDirections()
        }
        .onMapCameraChange { context in
            //will be called when the user is done interating with the map
            visibleRegion = context.region
        }
        
    }//body
    
    //get the directions!
    func getDirections(){
        route = nil
        guard let selectedResult else { return }
        
        //create a request to get directions and then do that in the background
        let request = MKDirections.Request()
        //source is starting location
        request.source = MKMapItem(placemark: MKPlacemark(coordinate: .rit))
        request.destination = selectedResult
        
        
        Task {
            let directions = MKDirections(request: request)
            let response = try? await directions.calculate()
            //f there are multiple routes pick the first one
            route = response?.routes.first
        }
    }
    
    
    
}//ContentView

extension CLLocationCoordinate2D {
    static let rit = CLLocationCoordinate2D(latitude: 43.0839, longitude: -77.6746)
}

extension MKCoordinateRegion {
    
    static let rochester = MKCoordinateRegion( center: CLLocationCoordinate2D(latitude: 43.0839, longitude: -77.6746), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
    
    static let ontarioShore = MKCoordinateRegion( center: CLLocationCoordinate2D(latitude: 43.9598, longitude: -78.1652), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
}

#Preview {
    ContentView()
}
