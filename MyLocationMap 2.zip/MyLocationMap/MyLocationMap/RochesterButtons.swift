
import SwiftUI
import MapKit

struct RochesterButtons: View {
    
    @Binding var position: MapCameraPosition
    
    @Binding var searchResults: [MKMapItem]
    
    //not a binding because we aren't going to change the value, just use it.
    var visibleRegion: MKCoordinateRegion?
    
    func search(for query: String) {
        
        let request = MKLocalSearch.Request()
        request.naturalLanguageQuery = query
        request.resultTypes = .pointOfInterest
        //if you pass in a value for search thn use that, otherwise use RIT
        request.region = visibleRegion ?? MKCoordinateRegion(center: .rit, span: MKCoordinateSpan(latitudeDelta: 0.0125, longitudeDelta: 0.0125))
        
        Task { //async task - more later in course
            
            let search = MKLocalSearch(request: request)
            let response = try? await search.start()
            searchResults = response?.mapItems ?? []
            
        }//Task
        
    }//search
    
    var body: some View {
        
        HStack {
            
            Button {
                search(for: "playground")
            } label: {
                Label("Playgrounds", systemImage: "figure.and.child.holdinghands")
            }
            .buttonStyle(.borderedProminent)
            
            Button {
                search(for: "beach")
            } label: {
                Label("Beaches", systemImage: "beach.umbrella")
            }
            .buttonStyle(.borderedProminent)
            
            Button {
                position = .region(.rochester)
            } label: {
                Label("Rochester", systemImage: "building.2")
            }
            .buttonStyle(.borderedProminent)
            
            Button {
                position = .region(.ontarioShore)
            } label: {
                Label("Ontario Beaches", systemImage: "water.waves")
            }
            .buttonStyle(.borderedProminent)
            
            Button {
                position = .camera(MapCamera(centerCoordinate: CLLocationCoordinate2D(latitude: 43.0839, longitude: -77.6746), distance: 980, heading: 242, pitch: 60))
            } label: {
                Label("RIT", systemImage: "building.columns.circle")
            }
            .buttonStyle(.borderedProminent)
            
            
            Button {
                position = .userLocation(fallback: .automatic)
            } label: {
                Label("Home", systemImage: "house")
            }
            .buttonStyle(.borderedProminent)
            
        }//HStack
        .labelStyle(.iconOnly)
        
    }//body
    
}//RochesterButtons


