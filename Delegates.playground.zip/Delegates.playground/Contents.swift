////unnamed tuple, references nums/value by position
//let tipAndTotal:(Double, Double) = (4.00, 25.19)
//
////get indiv values
//tipAndTotal.0
//tipAndTotal.1
//
////save indiv values
//let (tipAmt, totalAmt) = tipAndTotal
//tipAmt
//totalAmt
//
//
//
//
////named tuples
//let tipTotal = (tipAmt: 4.00, total: 25.19)
//let tipTotalExplicit: (tipAmt:Double, total:Double) = (4.00, 25.19)
//tipTotal.tipAmt
//tipTotal.total
//tipTotalExplicit.tipAmt
//tipTotalExplicit.total
//
//
////they are global, bc defined outside of any struct
//let total = 21.34
//let taxPct = 0.06
//let subTotal = total / (taxPct + 1)
//
//
////arrow means the return type
//func calcTipWith(tipPct: Double) -> (tipAmt: Double, total: Double) {
//    let tipAmt = subTotal + tipPct
//    let finalTotal = total + tipAmt
//    
//    return (tipAmt, finalTotal)
//    
//}
//
//calcTipWith(tipPct: 0.5)




//protocols
import Foundation

//add annotation to NOT make all funcs required
@objc protocol Speaker {
    func speak() //required
    @objc optional func tellJoke() //optional
}

//extends and conforms/implements
//can conform to as many protocols as you want but you can only implement one...they are like interfaces, sort of
class Deb: Speaker {
    func speak() {
        print("Hello I am Deb!")
    }
    
    func tellJoke() {
        print("Q: What did Sushi A say to Sushi B?")
    }
}


class Bryan: Speaker {
    func speak() {
        print("Hi this is Bryan")
    }
    
    func tellJoke() {
        print("Q: What's the object branded way to become wealthy?")
    }
    
    func writeTutorial() {
        print("I'm on it")
    }
}



class Animal {}
class Dog: Animal, Speaker{
    func speak() {
        print("Woof!")
    }
}

//to make this obj a type 'Speaker', you must say so, otherwise it will default to type "Bryan"
var speaker: Speaker = Bryan()
//'is' keyword is only used to check the type
//while it is a Bryan object, it only knows about things that are specific to speaker and only identifies as a Speaker object
if speaker is Bryan {
    print("Hi, I'm a Bryan")
    (speaker as! Bryan).writeTutorial()
}


//speaker.writeTutorial()
//force cast to a Bryan object
(speaker as! Bryan).writeTutorial()
speaker = Deb()
speaker.speak()

//optional func means it may not exist, means in Dog you don't have to provide fucntionality there. It won't crash even if Dog tellJoke doesn't exists
speaker.tellJoke?()
speaker = Dog()
speaker.tellJoke?()


protocol MtgSimulatorDelegate  {
    //anythign that conforms must implement these two methods
    func mtgSimulatorDidStart(sim: MtgSimulator, a:Speaker, b:Speaker)
    func mtgSimulatorDidEnd(sim: MtgSimulator, a:Speaker, b:Speaker)
}

class LoggingMtgSimulator: MtgSimulatorDelegate {
    func mtgSimulatorDidStart(sim: MtgSimulator, a: Speaker, b: Speaker) {
        print("mtg started")
    }
    
    func mtgSimulatorDidEnd(sim: MtgSimulator, a: Speaker, b: Speaker) {
        print("mtg ended")
    }
    
                
}



class MtgSimulator {

    let a: Speaker
    let b: Speaker
    
    //making it optional, typical of delegate properties, so it runs even if the delegate isn't listed for events
    var delegate: MtgSimulatorDelegate?
    
    init(a:Speaker, b:Speaker){
        self.a = a
        self.b = b
        delegate = self
    }
    
    func simulate() {
        print("off to a ameeting...")
        //using optional chaingin to if it doesn't exist, the meeting will still run
        delegate?.mtgSimulatorDidStart(sim: self, a: a, b: b)
        a.speak()
        b.speak()
        delegate?.mtgSimulatorDidEnd(sim: self, a: a, b: b)
        print("leaving mtg now...")
        //why are these optional functions
        a.tellJoke?()
        b.tellJoke?()
    }
}


extension MtgSimulator: MtgSimulatorDelegate {
    func mtgSimulatorDidStart(sim: MtgSimulator, a: Speaker, b: Speaker) {
        print("Started.........")
    }
    
    func mtgSimulatorDidEnd(sim: MtgSimulator, a: Speaker, b: Speaker) {
        print("Ended.........")
    }
    
}


let sim = MtgSimulator(a: Deb(), b:Bryan())
//sim.delegate = LoggingMtgSimulator()
sim.simulate()
//notify another class whent the meeting ends

