//
//  LocationaManager.swift
//  CoreLocationExample
//
//  Created by Emma Edgar on 2/29/24.
//

import Foundation
import CoreLocation
import SwiftUI

@Observable
class LocationManager: NSObject {
    
    private let locationManager = CLLocationManager()
    private let geocoder = CLGeocoder()
    
    // these properties will be "published" to observers
    var locationError = false
    var permissionsError = false
    var status: CLAuthorizationStatus = .notDetermined
    var location: CLLocation? = nil
    var placemark: CLPlacemark? = nil // for results of reverse geocoding
    
    //why is this an override?
    override init() {
        super.init()
        
        locationManager.delegate = self
        //bigger accuracy, bigger battery drain
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        
        //request permission - if you haven't set th strings you wont see the request
        DispatchQueue.global().async{
            //anything that impeeds the ui from beingresponsive, doing async
            if CLLocationManager.locationServicesEnabled() {
                self.locationManager.requestWhenInUseAuthorization()
            }
        }
        
        //if location changes, give updates
        locationManager.startUpdatingLocation()
    }//init
    
    private func geocode() {
        //use guard to make sure it actually has a location! Works like if-let since location is optional BUT with guard-let we don't have an if{} block to execute
        guard let location = self.location else { return }
        //something about ambda/trailing closures/can do anoher syntax...what makes that syntax different
        
        //if places does exist, we want the first one in the data structure
        geocoder.reverseGeocodeLocation(location) { places, error in
            if error == nil {
                //not on the main thread so we need to use self
                self.placemark = places?[0]
            } else {
                self.placemark = nil
            }
        }//reverse geocoder
        
    }//geocode
    
    func getLocation() {
        locationManager.requestLocation()
    }
    
}//locationManager

//extension addsfunctionality
//it separates things for the class and protocol. makes thecalss shorter
//
extension LocationManager: CLLocationManagerDelegate {
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        //get last elt otherwise just return
        guard let location = locations.last else { return }
        
        //because this is observable, anything that is listening can update the UI?
        //even though we are in the extension, we can still access the thing we are extending
        self.location = location
        locationError = false
        geocode()
    }
    
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print(error.localizedDescription)
        locationError = true
    }
    
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        //nything listening to a change in status can react to this
        status = manager.authorizationStatus
        
        switch status {
            
        case.restricted:
            permissionsError = true
            return
            
        case.denied:
            permissionsError = true
            return
            
        case.notDetermined:
            permissionsError = true
            return
            
        case.authorizedWhenInUse:
            permissionsError = true
            return
            
        case.authorizedAlways:
            permissionsError = true
            return
            
        @unknown default:
            break
        }//switch
    }//change authorization
    
}//extension
