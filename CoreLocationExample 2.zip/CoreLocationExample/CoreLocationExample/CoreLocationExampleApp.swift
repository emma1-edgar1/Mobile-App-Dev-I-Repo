//
//  CoreLocationExampleApp.swift
//  CoreLocationExample
//
//  Created by Matthew Incardona on 2/29/24.
//

import SwiftUI

@main
struct CoreLocationExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
