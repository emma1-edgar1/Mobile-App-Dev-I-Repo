//
//  ContentView.swift
//  CoreLocationExample
//
//  Created by Matthew Incardona on 2/29/24.
//

import SwiftUI
import CoreLocation
import CoreLocationUI
//in ios16 they added another way to ask for permission so we need corelocationUI

struct ContentView: View {
    
    
    var lm = LocationManager()
    
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE, MM dd y, hh:mm a"
        return formatter
    }
    
    //optional chaining and nil coalescing for force unwrapping
    var latitutde: String{ String(format: "%.4f", lm.location?.coordinate.latitude ?? 0) }
    var longitude: String{ String(format: "%.4f", lm.location?.coordinate.longitude ?? 0) }
    var altitude: String{ String(format: "%.4f", lm.location?.altitude ?? 0) }
    var hAccuracy: String{ String(format: "%.4f", lm.location?.horizontalAccuracy ?? 0) }
    var vAccuracy: String{ String(format: "%.4f", lm.location?.verticalAccuracy ?? 0) }
    var timestamp: String{ dateFormatter.string(from: lm.location?.timestamp ?? Date()) }
    
    var course: String { String(format: "%.4f", lm.location?.course ?? 0)}
    var speed: String { String(format: "%.4f", lm.location?.speed ?? 0)}
    //can et pieces of description: thougoughfare, locatlity, etc.
    var placemark: String { "\(lm.placemark?.description ?? "XXX")" }
    
    var status: CLAuthorizationStatus { lm.status }
    
    var locationError: Bool { lm.locationError }
    
    var permissionsError: Bool { lm.permissionsError }
    
    
    var body: some View {
        VStack(alignment: .leading, spacing: 5 ) {
            
            Text("Latitude: \(latitutde)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue, lineWidth: 4))
            
            
            Text("Longitude: \(longitude)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue, lineWidth: 4))
            
            Text("Altitude: \(altitude)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue, lineWidth: 4))
            
            
            Text("h.Accuracy: \(hAccuracy)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue, lineWidth: 4))
            
            
            Text("v.Accuracy: \(vAccuracy)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue, lineWidth: 4))
            
            Text("Timestamp: \(timestamp)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue,lineWidth: 4))
            
            Text("Speed: \(speed)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue,lineWidth: 4))
            
            Text("Course: \(course)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue,lineWidth: 4))
            
            Text("Placemark: \(placemark)")
                .padding()
                .frame(maxWidth: /*@START_MENU_TOKEN@*/.infinity/*@END_MENU_TOKEN@*/, alignment: .leading)
                .overlay(RoundedRectangle(cornerRadius: 16)
                    .stroke(.blue,lineWidth: 4))
            
            
        }//VStack
        .padding()
        //can be on anything in the view, caould be on any of the other properties in the view. Needs a state value so it will appea on the screen when state is redrawn. how to handle alerts and what does it show.
        .alert("Error Retrieving Location", isPresented: .constant(locationError)){
            Button("OK", role: .cancel) {
                //not going to doanything when clicked
            }
        } message: {
            Text("There was an error retrieving your location")
        }
        
        .alert("Location Access is denied", isPresented: .constant(permissionsError)){
            Button("Settings", role: .none) {
                goToDeviceSettings()
            }
        } message: {
            Text("Your location is needed")
        }
        
    }//body
}//contentview

extension ContentView {
    func goToDeviceSettings() {
        //you can get to settings by a url?
        guard let url = URL.init(string: UIApplication.openSettingsURLString) else { return }
            //using the UIApplication class, which is what we are inheriting from.
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
    }
}

#Preview {
    ContentView()
}
