//
//  ContentView.swift
//  locationButtonExample
//
//  Created by GCCISAdmin on 3/5/24.
//

import SwiftUI
import CoreLocation
import CoreLocationUI

struct ContentView: View {
    
    
    var locationManager = LocationManager()
    
    
    var body: some View {
        VStack {
            if let location = locationManager.location {
                Text("Your location: \(location.latitude), \(location.longitude)")
            }
//            LocationButton(.sendCurrentLocation) {
//                locationManager.requestLocation()
//            }
            
            
            LocationButton(action: {
                locationManager.requestLocation()
            }) 
//            .labelStyle(.iconOnly).symbolVariant(.none)
            
            .frame(height: 44)
            
            .foregroundStyle(.white)
            .cornerRadius(15)
            .labelStyle(.titleAndIcon)
            .symbolVariant(.fill)
            .tint(.purple)
            .padding()
            
            
            .padding()
        }//VStack
        .padding()
    }//body
}//contentView

#Preview {
    ContentView()
}
