//
//  locationButtonExampleApp.swift
//  locationButtonExample
//
//  Created by GCCISAdmin on 3/5/24.
//

import SwiftUI

@main
struct locationButtonExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
