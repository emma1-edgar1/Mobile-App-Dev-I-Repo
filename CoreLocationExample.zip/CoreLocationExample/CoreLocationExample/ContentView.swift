//
//  ContentView.swift
//  CoreLocationExample
//
//  Created by Matthew Incardona on 2/29/24.
//

import SwiftUI
import CoreLocation
import CoreLocationUI
//in ios16 they added another way to ask for permission so we need corelocationUI

struct ContentView: View {
    
    
    var lm = LocationManager()
    
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateFormat = "EEEE, MM dd y, hh:mm a"
        return formatter
    }
    
    //optional chaining and nil coalescing for force unwrapping
    var latitutde: String{ String(format: "%.4f", lm.location?.coordinate.latitude ?? 0) }
    var longitude: String{ String(format: "%.4f", lm.location?.coordinate.longitude ?? 0) }
    var altitude: String{ String(format: "%.4f", lm.location?.altitude ?? 0) }
    var hAccuracy: String{ String(format: "%.4f", lm.location?.horizontalAccuracy ?? 0) }
    var vAccuracy: String{ String(format: "%.4f", lm.location?.verticalAccuracy ?? 0) }
    var timestamp: String{ dateFormatter.string(from: lm.location?.timestamp ?? Date()) }
    
    var couse: String { String(format: "%.4f", lm.location?.course ?? 0)}
    var speed: String { String(format: "%.4f", lm.location?.speed ?? 0)}
    //can et pieces of description: thougoughfare, locatlity, etc.
    var placemark: String { "\(lm.placemark?.description ?? "XXX")" }
    
    var status: CLAuthorizationStatus { lm.status }
    
    var locationError: Bool { lm.locationError }
    
    var permissionsError: Bool { lm.permissionsError }
    
    
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!")
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
