//
//  ContentView.swift
//  MyLocationMap
//
//  Created by bfrench on 3/7/24.
//

import SwiftUI
import MapKit

struct ContentView: View {
    
    @State private var searchResults: [MKMapItem] = []
    @State private var position: MapCameraPosition = .automatic
    
    var body: some View {
        
        Map(position: $position) {
            
            //Marker("RIT", coordinate: .rit)
            
            Annotation("RIT", coordinate: .rit) {
                
                ZStack {
                    
                    RoundedRectangle(cornerRadius: 5)
                        .fill(.background)
                    
                    RoundedRectangle(cornerRadius: 5)
                        .stroke(.secondary, lineWidth: 5)
                    
                    Image(systemName: "building.columns")
                        .padding(5)
                    
                }//ZStack
                
            }//Annotation
            .annotationTitles(.hidden)
            
            ForEach( searchResults, id: \.self) { result in
                Marker(item: result)
            }
            
//            Marker("U of R", monogram: Text("UoR"), coordinate: CLLocationCoordinate2D(latitude: 43.1306, longitude: -77.6260))
//                .tint(.purple)
//            Marker("U of R", systemImage: "car.fill", coordinate: CLLocationCoordinate2D(latitude: 43.1306, longitude: -77.6260))
            
        }//Map
        .mapStyle(.hybrid(elevation: .realistic))
        .safeAreaInset(edge: .bottom) {
            
            HStack {
                Spacer()
                RochesterButtons(position: $position, searchResults: $searchResults)
                Spacer()
            }//HStack
            
        }//safeareainset
        .onChange(of: searchResults) {
            position = .automatic
        }
        
    }//body
}//ContentView

extension CLLocationCoordinate2D {
    static let rit = CLLocationCoordinate2D(latitude: 43.0839, longitude: -77.6746)
}

extension MKCoordinateRegion {
    
    static let rochester = MKCoordinateRegion( center: CLLocationCoordinate2D(latitude: 43.0839, longitude: -77.6746), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
    
    static let ontarioShore = MKCoordinateRegion( center: CLLocationCoordinate2D(latitude: 43.9598, longitude: -78.1652), span: MKCoordinateSpan(latitudeDelta: 0.1, longitudeDelta: 0.1))
}

#Preview {
    ContentView()
}
