class Monster {
    private var numHeads: Int = 1
    private var name: String = ""
    private var weapons: [String] = []
    private var undead: Bool
    
    //getter and setters - don't need 'return' unless you want it
    func getNumHeads() -> Int{numHeads}
    //func funcName(argumentLabel parameterLabel:Type [,...]) -> returnType
    //arg labels are used when CALLING the func, param labels are used IN the func
    //to call this func: setNumHeads(5).
    //Without the _, it would be: setNumHeads(_numHeads:5). The param label becomes the arg label too.
    func setNumHeads(_ _numHeads: Int) {
        if _numHeads < 0 || _numHeads > 1000 {
        } else {
            numHeads = _numHeads
        }
    }
    
    func getName() -> String { name }
    //preferred naming conventions
    //parameter name is also the arg name
    //to call this func: set(name: "Dwarf")
    func set(name:String) {
        self.name = name
    }
    
    func getWeapons() -> [String]{ weapons }
    func set(weapons:[String]) {
        self.weapons = weapons
    }
    
    
    //by the time it is done initializing, everything must have a value so we need an initializer
    
    //internal - within source module!! this is the default. Any file in the project can use the value through this class.
    
    //designated initializer - by the time this is done running, all need to have values!
    //methods dont exists until all properties are set, so cant use setters in the initializers UNLESS vars have initial values
    init(numHeads: Int, name: String, weapons: [String], undead: Bool) {
        self.undead = undead
        setNumHeads(numHeads)
        set(name:name)
        set(weapons: weapons)
//        self.numHeads = numHeads
//        self.name = name
//        self.weapons = weapons

    } //designated init
    
    //can only call other init within the same class
    convenience init() {
        self.init(numHeads: 1, name: "Orc", weapons: [], undead: false)
    }
}
